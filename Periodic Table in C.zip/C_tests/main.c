#include <stdio.h>
#include <stdlib.h>

int main()
{
    int anum;
    const char periodic_table[7][32][120] = {
        //Period 1
        {
            "H 1s(1); Radioactive: No; Relative atomic mass: 1.008",
            "He 1s(2); Radioactive: No; Relative atomic mass: 4.003"
        },

        //Period 2
        {
            "Li [He]2s(1); Radioactive: No; Relative atomic mass: 6.941",
            "Be [He]2s(2); Radioactive: No; Relative atomic mass: 9.012",
            "B [He]2s(2)2p(1); Radioactive: No; Relative atomic mass: 10.811",
            "C [He]2s(2)2p(2); Radioactive: No; Relative atomic mass: 12.011",
            "N [He]2s(2)2p(3); Radioactive: No; Relative atomic mass: 14.007",
            "O [He]2s(2)2p(4); Radioactive: No; Relative atomic mass: 15.999",
            "F [He]2s(2)2p(5); Radioactive: No; Relative atomic mass: 18.998",
            "Ne [He]2s(2)2p(6); Radioactive: No; Relative atomic mass: 20.180"
        },

        //Period 3
        {
            "Na [Ne]3s(1); Radioactive: No; Relative atomic mass: 22.990",
            "Mg [Ne]3s(2); Radioactive: No; Relative atomic mass: 24.305",
            "Al [Ne]3s(2)3p(1); Radioactive: No; Relative atomic mass: 26.982",
            "Si [Ne]3s(2)3p(2); Radioactive: No; Relative atomic mass: 28.085",
            "P [Ne]3s(2)3p(3); Radioactive: No; Relative atomic mass: 30.974",
            "S [Ne]3s(2)3p(4); Radioactive: No; Relative atomic mass: 32.065",
            "Cl [Ne]3s(2)3p(5); Radioactive: No; Relative atomic mass: 35.453",
            "Ar [Ne]3s(2)3p(6); Radioactive: No; Relative atomic mass: 39.948"
        },

        //Period 4
        {
            "K [Ar]4s(1); Radioactive: No; Relative atomic mass: 39.098",
            "Ca [Ar]4s(2); Radioactive: No; Relative atomic mass: 40.078",
            "Sc [Ar]3d(1)4s(2); Radioactive: No; Relative atomic mass: 44.956",
            "Ti [Ar]3d(2)4s(2); Radioactive: No; Relative atomic mass: 47.867",
            "V [Ar]3d(3)4s(2); Radioactive: No; Relative atomic mass: 50.942",
            "Cr [Ar]3d(5)4s(1); Radioactive: No; Relative atomic mass: 51.996",
            "Mn [Ar]3d(5)4s(2); Radioactive: No; Relative atomic mass: 54.938",
            "Fe [Ar]3d(6)4s(2); Radioactive: No; Relative atomic mass: 55.845",
            "Co [Ar]3d(7)4s(2); Radioactive: No; Relative atomic mass: 58.933",
            "Ni [Ar]3d(8)4s(2); Radioactive: No; Relative atomic mass: 58.693",
            "Cu [Ar]3d(10)4s(1); Radioactive: No; Relative atomic mass: 63.546",
            "Zn [Ar]3d(10)4s(2); Radioactive: No; Relative atomic mass: 65.380",
            "Ga [Ar]3d(10)4s(2)4p(1); Radioactive: No; Relative atomic mass: 69.723",
            "Ge [Ar]3d(10)4s(2)4p(2); Radioactive: No; Relative atomic mass: 72.630",
            "As [Ar]3d(10)4s(2)4p(3); Radioactive: No; Relative atomic mass: 74.922",
            "Se [Ar]3d(10)4s(2)4p(4); Radioactive: No; Relative atomic mass: 78.971",
            "Br [Ar]3d(10)4s(2)4p(5); Radioactive: No; Relative atomic mass: 79.904",
            "Kr [Ar]3d(10)4s(2)4p(6); Radioactive: No; Relative atomic mass: 83.798"
        },

        //Period 5
        {
            "Rb [Kr]5s(1); Radioactive: No; Relative atomic mass: 85.468",
            "Sr [Kr]5s(2); Radioactive: No; Relative atomic mass: 87.620",
            "Y [Kr]4d(1)5s(2); Radioactive: No; Relative atomic mass: 88.906",
            "Zr [Kr]4d(2)5s(2); Radioactive: No; Relative atomic mass: 91.224",
            "Nb [Kr]4d(4)5s(1); Radioactive: No; Relative atomic mass: 92.906",
            "Mo [Kr]4d(5)5s(1); Radioactive: No; Relative atomic mass: 95.950",
            "Tc [Kr]4d(5)5s(2); Radioactive: Yes; Relative atomic mass: 98.000",
            "Ru [Kr]4d(7)5s(1); Radioactive: No; Relative atomic mass: 101.070",
            "Rh [Kr]4d(8)5s(1); Radioactive: No; Relative atomic mass: 102.906",
            "Pd [Kr]4d(10); Radioactive: No; Relative atomic mass: 106.420",
            "Ag [Kr]4d(10)5s(1); Radioactive: No; Relative atomic mass: 107.868",
            "Cd [Kr]4d(10)5s(2); Radioactive: No; Relative atomic mass: 112.414",
            "In [Kr]4d(10)5s(2)5p(1); Radioactive: No; Relative atomic mass: 114.818",
            "Sn [Kr]4d(10)5s(2)5p(2); Radioactive: No; Relative atomic mass: 118.710",
            "Sb [Kr]4d(10)5s(2)5p(3); Radioactive: No; Relative atomic mass: 121.760",
            "Te [Kr]4d(10)5s(2)5p(4); Radioactive: No; Relative atomic mass: 127.600",
            "I [Kr]4d(10)5s(2)5p(5); Radioactive: No; Relative atomic mass: 126.904",
            "Xe [Kr]4d(10)5s(2)5p(6); Radioactive: No; Relative atomic mass: 131.293"
        },

        //Period 6
        {
            "Cs [Xe]6s(1); Radioactive: No; Relative atomic mass: 132.905",
            "Ba [Xe]6s(2); Radioactive: No; Relative atomic mass: 137.327",
            "La [Xe]5d(1)6s(2); Radioactive: No; Relative atomic mass: 138.905",
            "Ce [Xe]4f(1)5d(1)6s(2); Radioactive: No; Relative atomic mass: 140.116",
            "Pr [Xe]4f(3)6s(2); Radioactive: No; Relative atomic mass: 140.908",
            "Nd [Xe]4f(4)6s(2); Radioactive: No; Relative atomic mass: 144.242",
            "Pm [Xe]4f(5)6s(2); Radioactive: Yes; Relative atomic mass: 145.000",
            "Sm [Xe]4f(6)6s(2); Radioactive: No; Relative atomic mass: 150.360",
            "Eu [Xe]4f(7)6s(2); Radioactive: No; Relative atomic mass: 151.964",
            "Gd [Xe]4f(7)5d(1)6s(2); Radioactive: No; Relative atomic mass: 157.250",
            "Tb [Xe]4f(9)6s(2); Radioactive: No; Relative atomic mass: 158.925",
            "Dy [Xe]4f(10)6s(2); Radioactive: No; Relative atomic mass: 162.500",
            "Ho [Xe]4f(11)6s(2); Radioactive: No; Relative atomic mass: 164.930",
            "Er [Xe]4f(12)6s(2); Radioactive: No; Relative atomic mass: 167.259",
            "Tm [Xe]4f(13)6s(2); Radioactive: No; Relative atomic mass: 168.934",
            "Yb [Xe]4f(14)6s(2); Radioactive: No; Relative atomic mass: 173.054",
            "Lu [Xe]4f(14)5d(1)6s(2); Radioactive: No; Relative atomic mass: 174.967",
            "Hf [Xe]4f(14)5d(2)6s(2); Radioactive: No; Relative atomic mass: 178.490",
            "Ta [Xe]4f(14)5d(3)6s(2); Radioactive: No; Relative atomic mass: 180.948",
            "W [Xe]4f(14)5d(4)6s(2); Radioactive: No; Relative atomic mass: 183.840",
            "Re [Xe]4f(14)5d(5)6s(2); Radioactive: No; Relative atomic mass: 186.207",
            "Os [Xe]4f(14)5d(6)6s(2); Radioactive: No; Relative atomic mass: 190.230",
            "Ir [Xe]4f(14)5d(7)6s(2); Radioactive: No; Relative atomic mass: 192.217",
            "Pt [Xe]4f(14)5d(9)6s(1); Radioactive: No; Relative atomic mass: 195.084",
            "Au [Xe]4f(14)5d(10)6s(1); Radioactive: No; Relative atomic mass: 196.967",
            "Hg [Xe]4f(14)5d(10)6s(2); Radioactive: No; Relative atomic mass: 200.592",
            "Tl [Xe]4f(14)5d(10)6s(2)6p(1); Radioactive: No; Relative atomic mass: 204.383",
            "Pb [Xe]4f(14)5d(10)6s(2)6p(2); Radioactive: No; Relative atomic mass: 207.200",
            "Bi [Xe]4f(14)5d(10)6s(2)6p(3); Radioactive: No; Relative atomic mass: 208.980",
            "Po [Xe]4f(14)5d(10)6s(2)6p(4); Radioactive: Yes; Relative atomic mass: 209.000",
            "At [Xe]4f(14)5d(10)6s(2)6p(5); Radioactive: Yes; Relative atomic mass: 210.000",
            "Rn [Xe]4f(14)5d(10)6s(2)6p(6); Radioactive: Yes; Relative atomic mass: 222.000"
        },

        //Period 7
        {
            "Fr [Rn]7s(1); Radioactive: Yes; Relative atomic mass: 223.000",
            "Ra [Rn]7s(2); Radioactive: Yes; Relative atomic mass: 226.000",
            "Ac [Rn]6d(1)7s(2); Radioactive: Yes; Relative atomic mass: 227.000",
            "Th [Rn]6d(2)7s(2); Radioactive: Yes; Relative atomic mass: 232.038",
            "Pa [Rn]5f(2)6d(1)7s(2); Radioactive: Yes; Relative atomic mass: 231.036",
            "U [Rn]5f(3)6d(1)7s(2); Radioactive: Yes; Relative atomic mass: 238.029",
            "Np [Rn]5f(4)6d(1)7s(2); Radioactive: Yes; Relative atomic mass: 237.000",
            "Pu [Rn]5f(6)7s(2); Radioactive: Yes; Relative atomic mass: 244.000",
            "Am [Rn]5f(7)7s(2); Radioactive: Yes; Relative atomic mass: 243.000",
            "Cm [Rn]5f(7)6d(1)7s(2); Radioactive: Yes; Relative atomic mass: 247.000",
            "Bk [Rn]5f(9)7s(2); Radioactive: Yes; Relative atomic mass: 247.000",
            "Cf [Rn]5f(10)7s(2); Radioactive: Yes; Relative atomic mass: 251.000",
            "Es [Rn]5f(11)7s(2); Radioactive: Yes; Relative atomic mass: 252.000",
            "Fm [Rn]5f(12)7s(2); Radioactive: Yes; Relative atomic mass: 257.000",
            "Md [Rn]5f(13)7s(2); Radioactive: Yes; Relative atomic mass: 258.000",
            "No [Rn]5f(14)7s(2); Radioactive: Yes; Relative atomic mass: 259.000",
            "Lr [Rn]5f(14)7s(2)7p(1); Radioactive: Yes; Relative atomic mass: 266.000",
            "Rf [Rn]5f(14)6d(2)7s(2); Radioactive: Yes; Relative atomic mass: 267.000",
            "Db [Rn]5f(14)6d(3)7s(2); Radioactive: Yes; Relative atomic mass: 268.000",
            "Sg [Rn]5f(14)6d(4)7s(2); Radioactive: Yes; Relative atomic mass: 271.000",
            "Bh [Rn]5f(14)6d(5)7s(2); Radioactive: Yes; Relative atomic mass: 270.000",
            "Hs [Rn]5f(14)6d(6)7s(2); Radioactive: Yes; Relative atomic mass: 277.000",
            "Mt [Rn]5f(14)6d(7)7s(2); Radioactive: Yes; Relative atomic mass: 278.000",
            "Ds [Rn]5f(14)6d(9)7s(1); Radioactive: Yes; Relative atomic mass: 281.000",

        }
    };

        scanf("%d", &anum);

        //1st period
        if(anum - 1 < 2){
            printf("%s", periodic_table[0][anum - 1]);
        }else
        //2nd period
        if(anum - 1 < 10 && anum - 1 > 1){
            printf("%s", periodic_table[1][anum - 3]);
        }else
        //3rd period
        if(anum - 1 < 18 && anum - 1 > 9){
            printf("%s", periodic_table[2][anum - 11]);
        }else
        //4th period
        if(anum - 1 < 36 && anum - 1 > 17){
            printf("%s", periodic_table[3][anum - 19]);
        }else
        //5th period
        if(anum - 1 < 54 && anum - 1 > 35){
            printf("%s", periodic_table[4][anum - 37]);
        }else
        //6th period
        if(anum - 1 < 86 && anum - 1 > 53){
            printf("%s", periodic_table[5][anum - 55]);
        }else
        //7th period
        if(anum - 1 < 110 && anum - 1 > 85){
            printf("%s", periodic_table[6][anum - 87]);
        }



    return 0;
}
